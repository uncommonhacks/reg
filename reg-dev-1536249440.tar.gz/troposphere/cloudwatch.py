# Copyright (c) 2013, Mark Peek <mark@peek.org>
# All rights reserved.
#
# See LICENSE file for full license.

from . import AWSObject, AWSProperty
from .validators import boolean, exactly_one, json_checker, positive_integer


class MetricDimension(AWSProperty):
    props = {
        'Name': (str, True),
        'Value': (str, True),
    }


class Alarm(AWSObject):
    resource_type = "AWS::CloudWatch::Alarm"

    props = {
        'ActionsEnabled': (boolean, False),
        'AlarmActions': ([str], False),
        'AlarmDescription': (str, False),
        'AlarmName': (str, False),
        'ComparisonOperator': (str, True),
        'Dimensions': ([MetricDimension], False),
        'EvaluateLowSampleCountPercentile': (str, False),
        'EvaluationPeriods': (positive_integer, True),
        'ExtendedStatistic': (str, False),
        'InsufficientDataActions': ([str], False),
        'MetricName': (str, True),
        'Namespace': (str, True),
        'OKActions': ([str], False),
        'Period': (positive_integer, True),
        'Statistic': (str, False),
        'Threshold': (str, True),
        'TreatMissingData': (str, False),
        'Unit': (str, False),
    }

    def validate(self):
        conds = [
            'ExtendedStatistic',
            'Statistic',
        ]
        exactly_one(self.__class__.__name__, self.properties, conds)


class Dashboard(AWSObject):
    resource_type = "AWS::CloudWatch::Dashboard"

    props = {
        'DashboardBody': ((str, dict), True),
        'DashboardName': (str, False),
    }

    def validate(self):
        name = 'DashboardBody'
        if name in self.properties:
            dashboard_body = self.properties.get(name)
            self.properties[name] = json_checker(name, dashboard_body)
