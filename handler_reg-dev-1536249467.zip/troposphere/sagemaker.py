# Copyright (c) 2012-2018, Mark Peek <mark@peek.org>
# All rights reserved.
#
# See LICENSE file for full license.

from . import AWSObject, AWSProperty, Tags
from .validators import boolean, integer


class Endpoint(AWSObject):
    resource_type = "AWS::SageMaker::Endpoint"

    props = {
        'EndpointName': (str, False),
        'EndpointConfigName': (str, True),
        'Tags': (Tags, False),
    }


class ProductionVariant(AWSProperty):
    props = {
        'ModelName': (boolean, True),
        'VariantName': (str, True),
        'InitialInstanceCount': (integer, True),
        'InstanceType': (str, True),
    }


class EndpointConfig(AWSObject):
    resource_type = "AWS::SageMaker::EndpointConfig"

    props = {
        'EndpointConfigName': (str, False),
        'ProductionVariants': ([ProductionVariant], True),
        'Tags': (Tags, False),
    }


class ContainerDefinition(AWSProperty):
    props = {
        'ContainerHostname': (str, False),
        'Environment': (dict, False),
        'ModelDataUrl': (str, False),
        'Image': (str, True),
    }


class Model(AWSObject):
    resource_type = "AWS::SageMaker::Model"

    props = {
        'ExecutionRoleArn': (str, True),
        'PrimaryContainer': (ContainerDefinition, True),
        'ModelName': (str, False),
        'VpcConfig': (str, False),
        'Tags': (Tags, False),
    }


class NotebookInstance(AWSObject):
    resource_type = "AWS::SageMaker::NotebookInstance"

    props = {
        'KmsKeyId': (str, False),
        'DirectInternetAccess': (str, True),
        'SubnetId': (str, False),
        'NotebookInstanceName': (str, False),
        'InstanceType': (str, True),
        'LifecycleConfigName': (str, False),
        'SecurityGroupIds': ([str], False),
        'RoleArn': (str, True),
        'Tags': (Tags, False),
    }


class NotebookInstanceLifecycleConfig (AWSProperty):
    props = {
        'Content': (str, False),
    }


class NotebookInstanceLifecycleConfig(AWSObject):
    resource_type = "AWS::SageMaker::NotebookInstanceLifecycleConfig"

    props = {
        'NotebookInstanceLifecycleConfigName': (str, False),
        'OnCreate': (NotebookInstanceLifecycleConfig, False),
        'OnStart': (NotebookInstanceLifecycleConfig, False),
    }
